using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.InputSystem;

public static class ActiveAssetBundles
{
    //bundle name and full path.
    public static Dictionary<string,string> BundleLocations = new Dictionary<string,string>();
    public static Dictionary<string,AssetBundle> ActiveBundles = new Dictionary<string,AssetBundle>();

    public static int BundlesLoaded(){
        return BundleLocations.Count;
    }
    public static void ClearBundleDictionary(){
        BundleLocations.Clear();
    }
    public static bool IsEmpty(){
        if(BundleLocations.Count == 0){
            return true;
        }
        return false;
    }
    public static void LoadBundle(string name, string fullPath){
        BundleLocations.Add(name, fullPath);
        ActiveBundles.Add(name,AssetBundle.LoadFromFile(fullPath));
    }
    public static void UnloadBundle(string name, string fullPath){
        BundleLocations.Remove(name);
        ActiveBundles.Remove(name);
        AssetBundle.UnloadAllAssetBundles(true);
        foreach (KeyValuePair<string, string> pair in BundleLocations){
            ActiveBundles.Add(pair.Key,AssetBundle.LoadFromFile(pair.Value));
        }
    }
    public static void ReloadBundles(){
        AssetBundle.UnloadAllAssetBundles(true);
        foreach (KeyValuePair<string, string> pair in BundleLocations){
            ActiveBundles.Add(pair.Key,AssetBundle.LoadFromFile(pair.Value));
        }
    }
}
