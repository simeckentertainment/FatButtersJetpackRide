using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameplayButtonData : MonoBehaviour
{
    public bool activated;
    // Start is called before the first frame update
    private void OnMouseDown() {
        activated = true;
    }
}
