using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class MainMenuButtonHandler : MonoBehaviour
{
[Header("Must be set")]
[SerializeField] ButtonFunction function;


[Header("Use these as needed")]
[SerializeField] SceneLoadData sceneLoadData;
[SerializeField] CollectibleData collectibleData;

MainMenuCameraMover cameraMover;
Color darkenedButton = new Color(0.3f,0.3f,0.3f);


[Header("Submenu stuff")]
[SerializeField] GameObject OtherMenuObject;
[SerializeField] GameObject ThisMenuObject;

[Header("Level Select stuff")]

//public bool isQuit;
Renderer mat;
[SerializeField] bool buttonActive;
Color originalColor;
[SerializeField] SaveManager saveManager;
[Header("Settings Menu Stuff")]
[SerializeField] SettingsMenuButton settingsMenuButton;
//[System.NonSerialized] ButtersFileLibrary levelDataLibrary;
    
    // Start is called before the first frame update
    void Start()
    {
        //levelDataLibrary = FindAnyObjectByType<ButtersFileLibrary>();
        cameraMover = FindObjectOfType<MainMenuCameraMover>();
        mat = gameObject.GetComponent<Renderer>();
        //mat.material.color = Color.black;
    }
    void Update()
    {
        buttonActive = ButtonActive();
        if(!buttonActive){
            mat.material.color = darkenedButton;
        }
    }

    private bool ButtonActive()
    {

        return true;
    }
    void OnMouseDown() {
        if(!buttonActive) return;
        originalColor = mat.material.color;
        mat.material.color = Color.red;
    }
    void OnMouseUp(){
        if(!buttonActive) return;
        mat.material.color = originalColor;
        switch(function){
            case ButtonFunction.SelectLevel:
                OtherMenuObject.SetActive(true);
                ThisMenuObject.SetActive(false);
                break;
            case ButtonFunction.SubMenuBack:
            //we'll make this more extensible as we need to.
                OtherMenuObject.SetActive(true);
                ThisMenuObject.SetActive(false);
                break;
            case ButtonFunction.Back:
                cameraMover.MoveTo(cameraMover.MainMenu);
                break;         
            case ButtonFunction.Credits:
                cameraMover.MoveTo(cameraMover.CreditsMenu);
                break;
            case ButtonFunction.FuelUpgrade:
                if(PriceChecker(collectibleData.BONES,collectibleData.fuelUpgradeLevel)){
                    collectibleData.BONES -= collectibleData.fuelUpgradeLevel;
                    collectibleData.fuelUpgradeLevel += 1;
                    saveManager.Save();
                }
                break;
             case ButtonFunction.TummyUpgrade:
                if(PriceChecker(collectibleData.BONES,collectibleData.treatsUpgradeLevel)){
                    collectibleData.BONES -= collectibleData.treatsUpgradeLevel;
                    collectibleData.treatsUpgradeLevel += 1;
                    saveManager.Save();
                }
                break;
            case ButtonFunction.ProfitUpgrade:
                if(PriceChecker(collectibleData.BONES,collectibleData.profitUpgradeLevel)){
                    collectibleData.BONES -= collectibleData.profitUpgradeLevel;
                    collectibleData.profitUpgradeLevel += 1;
                    saveManager.Save();
                }
                break;
            case ButtonFunction.ThrustUpgrade:
                if(PriceChecker(collectibleData.BONES,collectibleData.thrustUpgradeLevel)){
                    collectibleData.BONES -= collectibleData.thrustUpgradeLevel;
                    collectibleData.thrustUpgradeLevel += 1;
                    saveManager.Save();
                }
                break;
            case ButtonFunction.Quit:
                Application.Quit();
                break;
            case ButtonFunction.SettingsMenuButton:
                ApplySettingsMenuOption();
                break;
            default:

                break;
        }
    }
    void ApplySettingsMenuOption(){
        switch(settingsMenuButton){
            case SettingsMenuButton.ResetData:
                saveManager.ResetSave();
                break;
            case SettingsMenuButton.PrivacyPolicy:
                Application.OpenURL("https://fatbutters.simeck.com/privacyPolicy.txt");
                break;
        }
    }

    bool PriceChecker(int available, int Cost){
        int amountPostTransaction = available-Cost;
        if(amountPostTransaction >= 0){
            return true;
        } else{
            return false;
        }
    }
    public enum ButtonFunction{
        SelectLevel,SubMenuBack,Start,Settings,Back,Credits,FuelUpgrade,TummyUpgrade,ProfitUpgrade,Quit,SettingsMenuButton,ThrustUpgrade
    };

    enum SettingsMenuButton{
        None,ResetData,PrivacyPolicy
    }
}
