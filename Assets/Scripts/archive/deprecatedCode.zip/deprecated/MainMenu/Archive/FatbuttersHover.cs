using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FatbuttersHover : MonoBehaviour
{
[SerializeField] public List<ParticleSystem> rocketParticles;
public float amplitude = 0.5f; // Amplitude of the oscillation
public float speed = 1.0f; // Speed of the oscillation
private float startY; // Butters' starting Y position
    

void Start(){
    for(int i=0; i<rocketParticles.Count;i++){
        rocketParticles[i].Play();
    }
    startY = transform.position.y; // Store the object's starting Y position
}
void Update(){
    float newY = startY + Mathf.Sin(Time.time * speed) * amplitude; // Calculate the new Y position
    transform.position = new Vector3(transform.position.x, newY, transform.position.z); // Update the object's position
}

}