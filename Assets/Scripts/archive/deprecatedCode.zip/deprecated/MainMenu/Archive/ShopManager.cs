using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class ShopManager : MainMenuCommonData
{
    [Header("Stats bar items")]
    [SerializeField] TMP_Text bonesText;
    [SerializeField] TMP_Text fuelText;
    [SerializeField] TMP_Text tummyText;
    [SerializeField] TMP_Text profitText;
    [Header("Shop Cost/upgrade levels")]
    [SerializeField] TMP_Text fuelCostText;
    [SerializeField] TMP_Text tummyCostText;
    [SerializeField] TMP_Text thrustCostText;

    [Header("Skin Selection stuff")]
    [SerializeField] TMP_Text skinTextLabel;
    [SerializeField] SkinOption[] butterySkins;
    [SerializeField] GameObject[] PurchaseSkinMenu;
    int currentIndex;
    [SerializeField] Transform ShopCorgiInstantiationLocation;
    GameObject currentModel;
    FatbuttersHover fatbuttersHover;

    // Start is called before the first frame update
    void Start()
    {
        currentIndex = saveManager.collectibleData.CurrentSkin;
        currentModel = null; //ensuring that the value is null because ModelSwap is expecting it to be null the first time.
        ModelSwap();
        PurchaseSkinMenu[currentIndex].SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        SetStatusTexts();
        SetCostTexts();
        PurchaseSkinMenu[currentIndex].SetActive(!saveManager.collectibleData.HaveSkins[saveManager.collectibleData.CurrentSkin]);
    }
    void SetStatusTexts(){
        bonesText.text = "Bones: " + saveManager.collectibleData.BONES.ToString();
        fuelText.text = "Fuel Upgrade: " + saveManager.collectibleData.fuelUpgradeLevel.ToString();
        tummyText.text = "Tummy Upgrade: " + saveManager.collectibleData.treatsUpgradeLevel.ToString();
        profitText.text = "Thrust Upgrade:" + saveManager.collectibleData.thrustUpgradeLevel.ToString();
    }

    void SetCostTexts(){
        fuelCostText.text =  saveManager.collectibleData.fuelUpgradeLevel.ToString();
        tummyCostText.text =  saveManager.collectibleData.treatsUpgradeLevel.ToString();
        thrustCostText.text = saveManager.collectibleData.thrustUpgradeLevel.ToString();
    }
    bool PriceChecker(int available, int Cost){
        int amountPostTransaction = available-Cost;
        if(amountPostTransaction >= 0){
            return true;
        } else{
            return false;
        }
    }

//Begin the button commands here.

    public void UpgradeFuel(){
        if(PriceChecker(saveManager.collectibleData.BONES,saveManager.collectibleData.fuelUpgradeLevel)){
            saveManager.collectibleData.BONES -= saveManager.collectibleData.fuelUpgradeLevel;
            saveManager.collectibleData.fuelUpgradeLevel += 1;
            saveManager.Save();
        }
    }
    public void UpgradeTummy(){
        if(PriceChecker(saveManager.collectibleData.BONES,saveManager.collectibleData.treatsUpgradeLevel)){
            saveManager.collectibleData.BONES -= saveManager.collectibleData.treatsUpgradeLevel;
            saveManager.collectibleData.treatsUpgradeLevel += 1;
            saveManager.Save();
        }
    }

    public void UpgradeThrust(){
        if(PriceChecker(saveManager.collectibleData.BONES,saveManager.collectibleData.thrustUpgradeLevel)){
            saveManager.collectibleData.BONES -= saveManager.collectibleData.thrustUpgradeLevel;
            saveManager.collectibleData.thrustUpgradeLevel += 1;
            saveManager.Save();
        }
    }

    public void SkinPickerLeft(){
        PurchaseSkinMenu[currentIndex].SetActive(false);
        currentIndex -=1;
        if(currentIndex < 0){
            currentIndex = saveManager.collectibleData.HaveSkins.Length-1;
        }
        saveManager.collectibleData.CurrentSkin = currentIndex;
        saveManager.Save();
        ModelSwap();
    }
    public void SkinPickerRight(){
        PurchaseSkinMenu[currentIndex].SetActive(false);
        currentIndex +=1;
        if(currentIndex > saveManager.collectibleData.HaveSkins.Length-1){
            currentIndex = 0;
        }
        saveManager.collectibleData.CurrentSkin = currentIndex;
        saveManager.Save();
        ModelSwap();
    }
    void ModelSwap(){
        if(currentModel != null){
            Destroy(currentModel);
        }
        GameObject tmpModel = ActiveAssetBundles.ActiveBundles["misc"].LoadAsset<GameObject>(butterySkins[currentIndex].assetPath);
        currentModel = Instantiate(tmpModel,ShopCorgiInstantiationLocation.position,ShopCorgiInstantiationLocation.rotation);
        skinTextLabel.text = "Current Skin:\n" + butterySkins[currentIndex].skinName;
        fatbuttersHover = currentModel.GetComponent<FatbuttersHover>();
        fatbuttersHover.enabled = true;
        try { 
        fatbuttersHover.rocketParticles[0].gameObject.SetActive(true);
        fatbuttersHover.rocketParticles[1].gameObject.SetActive(true);
        }catch{

        }
    }
    public void PurchaseSkin(){
        if(PriceChecker(saveManager.collectibleData.BONES,100)){
            //Social.ReportProgress(GPGSIds.achievement_skintastic, 100.0f, (bool success) => {Debug.Log("Bought a skin!");});
            saveManager.collectibleData.HaveSkins[currentIndex] = true;
            PurchaseSkinMenu[currentIndex].SetActive(false);
            saveManager.collectibleData.BONES -= 100;
            saveManager.Save();
        }
    }


}

