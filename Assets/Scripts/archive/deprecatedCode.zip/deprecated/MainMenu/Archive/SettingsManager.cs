using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using System.IO;
#if UNITY_ANDROID
using GooglePlayGames;
#endif
using UnityEngine.SocialPlatforms;
using RDG;

public class SettingsManager : MainMenuCommonData
{
    [SerializeField] public GameObject secretCodeDialog;
    [SerializeField] TMP_Text codeEntryButton;
    SetData setData;
    bool devnessProven;
    [SerializeField] TMP_Text GPGID;
    #if UNITY_ANDROID
    PlayGamesInitializer pgi;
    #endif

    // Start is called before the first frame update
    void Start()
    {
#if UNITY_ANDROID
        setData = GetComponent<SetData>();
        
        pgi = FindAnyObjectByType<PlayGamesInitializer>();
        GPGID.text = pgi.Error + "\n" + pgi.Token;

        if(pgi.Error != ""){
            GPGID.text = pgi.Error;
        } else {
            GPGID.text = pgi.Token;
        }
        #endif
    }

    // Update is called once per frame
    void Update()
    {
    }

    public void ResetData(){
        saveManager.ResetSave();
        AssetBundle.UnloadAllAssetBundles(true);
        SceneManager.LoadScene("Scenes/StatsAndLoaderScenes/1-AnalyticsChecker");
    }
    public void ViewPrivacyPolicy(){
        Application.OpenURL("https://fatbutters.simeck.com/privacyPolicy.txt");
    }
    public void CreateDevSave(){
        saveManager.CreateCompletedSave();
    }

    public void ToggleInputDialog(){
        if(secretCodeDialog.activeSelf){
            secretCodeDialog.SetActive(false);
            codeEntryButton.text = "Enter Secret Code";
        } else {
            secretCodeDialog.SetActive(true);
            codeEntryButton.text = "Hide secret code field";
        }
    }

    public void SecretCodeInvoker(){
            if(secretCodeDialog.GetComponentInChildren<TMP_InputField>().text == "Hi guys burgers and fries"){
                devnessProven = true;
                secretCodeDialog.GetComponentInChildren<TMP_InputField>().text = "Hi, dad :)";
            }
            if(devnessProven){
                setData.Invoke(secretCodeDialog.GetComponentInChildren<TMP_InputField>().text,0);
            } else {
                secretCodeDialog.GetComponentInChildren<TMP_InputField>().text = "You're not my real dad!";
            }
    }
    public void DeleteLocalAssetBundles()
    {
        string[] localFiles = Directory.GetFiles(Application.persistentDataPath + "/AssetBundles/");
        foreach(string file in localFiles) { File.Delete(file); }
        Directory.Delete(Application.persistentDataPath + "/AssetBundles/");
        AssetBundle.UnloadAllAssetBundles(true);
        SceneManager.LoadScene("Scenes/StatsAndLoaderScenes/1-AnalyticsChecker");
    }
    public void ReLoadLocalAssetBundles()
    {
        AssetBundle.UnloadAllAssetBundles(true);
        SceneManager.LoadScene("Scenes/StatsAndLoaderScenes/6-AssetLoader");
    }

    public void TestDeviceVibration()
    {
        Debug.Log("vibrating!");
        RDG.Vibration.Vibrate(100);
    }

    public void OpenCloudSaveUI(){
#if UNITY_ANDROID
        saveManager.ShowSelectUI();
#endif
    }

    public void OpenAchievementUI()
    {
        #if UNITY_ANDROID
        Social.ShowAchievementsUI();
        #endif
    }

}
