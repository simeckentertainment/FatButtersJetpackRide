using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AssetBundleRealizer : MonoBehaviour
{/*
    [SerializeField] bool DevLevelOverride;
    [SerializeField] int DevGameplayLevelOverride;
    [SerializeField] string path;
    [SerializeField] GameObject Player;
    LevelData levelData;
    [SerializeField] SceneLoadData sceneLoadData;
    [SerializeField] MusicManager music;
    List<GameObject> levelObjects;
    ButtersFileLibrary buttersFileLibrary;
    // Start is called before the first frame update
    void Awake()
    {
        buttersFileLibrary = FindAnyObjectByType<ButtersFileLibrary>();
        levelObjects = new List<GameObject>();
        if(DevLevelOverride){
            levelData = buttersFileLibrary.GetGameplayLevelData(DevGameplayLevelOverride);
        } else {
            levelData = buttersFileLibrary.GetGameplayLevelData(sceneLoadData.GameplaySceneToLoad);
        }
        LoadData();
        
    }
    void LoadData(){
        foreach(LevelObject obj in levelData.levelObjects){
            try{
            GameObject instantiatedObj = ActiveAssetBundles.ActiveBundles[obj.bundle].LoadAsset<GameObject>(obj.PrefabPath);
            instantiatedObj.tag = obj.tag;
            instantiatedObj.transform.position = obj.position;
            instantiatedObj.transform.rotation = obj.rotation;
            instantiatedObj.transform.localScale = obj.scale;
            InstanceDataParser idp = instantiatedObj.GetComponent<InstanceDataParser>();
            if(idp != null){
                idp.ExtraDataString = obj.ExtraData;
            }
            levelObjects.Add(Instantiate(instantiatedObj));
            } catch {
                Debug.Log("Can't spawn " + obj.name);
            }
        }
        RenderSettings.skybox = ActiveAssetBundles.ActiveBundles["skyboxes"].LoadAsset<Material>(levelData.Skybox);
        Player.transform.position = levelData.PlayerPos;
        music.songSelector = levelData.song;
    }
    public void ClearPlayingField(){
        foreach(GameObject obj in levelObjects){
            Destroy(obj);
        }
    }
    */
}


