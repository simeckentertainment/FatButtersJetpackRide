

using UnityEngine;
#if UNITY_ANDROID && !UNITY_EDITOR
using GooglePlayGames;
using GooglePlayGames.BasicApi;
#endif
using UnityEngine.SocialPlatforms;
using UnityEngine.SceneManagement;
using System.Drawing;
using Google.Play.Integrity;
using GooglePlayGames;
public class PlayGamesInitializer : MonoBehaviour
{

    [System.NonSerialized] public string Token;
    [System.NonSerialized] public string Error;

    [SerializeField] public Image[] darkenerImages;


    void Awake()//
    {
        #if UNITY_ANDROID && !UNITY_EDITOR
        //Initialize PlayGamesPlatform
        PlayGamesPlatform.Activate();
        LoginGooglePlayGames();
        #endif

        #if UNITY_EDITOR || !UNITY_ANDROID
        Token = "Not logged into Google Play";
        Error = "";
        #endif
        

    }
    void Start(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
    #if UNITY_ANDROID && !UNITY_EDITOR
    public void LoginGooglePlayGames()
    {
        PlayGamesPlatform.Instance.Authenticate((success) =>
        {
            if (success == SignInStatus.Success)
            {
                Debug.Log("Login with Google Play games successful.");

                PlayGamesPlatform.Instance.RequestServerSideAccess(true, code =>
                {
                    Debug.Log("Authorization code: " + code);
                    Token = code;
// This token serves as an example to be used for SignInWithGooglePlayGames
                });
            }
            else
            {
                Error = "Failed to retrieve Google play games authorization code";
                Debug.Log("Login Unsuccessful");
            }
        });
        
    }
#endif
}




