using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Services.Core;
using UnityEngine.SceneManagement;
using TMPro;
public class InitializationModuleManager : InitializationCommonFunctions
{
    // Start is called before the first frame update
    [SerializeField] GameObject CorgiRain;
    [SerializeField] AnalyticsManager analytics;
    [SerializeField] PlayGamesInitializer playGamesInitializer;
    [SerializeField] MaintenanceManager maintenance;
    [SerializeField] AssetLoader assets;


    async void Start()
    {
        await UnityServices.InitializeAsync();
        saveManager.EnsureSaveFileExists();
        StartCoroutine(CoroutineLauncher());
    }

    IEnumerator CoroutineLauncher(){
        //Analytics first...
        yield return StartCoroutine(analytics.CheckForConsent());
        while (!saveManager.userInfo.dataCollectionChosen){
            yield return null;
        }


        //swap the display
        analytics.gameObject.SetActive(false);


        //Now Google Play Games stuff...
        //yield return StartCoroutine(playGamesInitializer.StartPlayGamesInitializationProcess());


        //Swap the display...
        maintenance.gameObject.SetActive(true);
        yield return null;





        //Then maintenance stuff...
        

        yield return StartCoroutine(maintenance.CheckMaintenanceData());
        //yield return initData.maintenaceMode = maintenance.maintenaceMode;
        yield return maintenance.MaintenanceText.text = maintenance.messageString;
        //yield return initData.bypassDownload = maintenance.bypassDownload;

        //if(!initData.bypassDownload && !initData.maintenaceMode){
            //maintenance.gameObject.SetActive(false);
            //assets.gameObject.SetActive(true);
            //CorgiRain.SetActive(true);
        //}
        yield return StartCoroutine(assets.DownloadCoroutineLauncher());
        if(assets.NeedToUpdateFromAppStore){
            yield return assets.LabelText.text = "There is an update available from the App store.";
            yield return assets.ProgressText.text = "If it's not available now, it will be shortly.";
            assets.DownloadButton.SetActive(true);
            yield return assets.DownloadButton.activeSelf;
        } else{
            yield return StartCoroutine(LaunchMainMenu());
        }
        yield return null;
    }
    IEnumerator LaunchMainMenu(){
        SceneManager.LoadScene("Scenes/MainMenuV2");
        yield return null;
    }
}
