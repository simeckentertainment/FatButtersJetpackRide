using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Text.RegularExpressions;
using System.Linq;
using UnityEngine.SceneManagement;
using TMPro;
using UnityEngine.UI;

public class AssetBundleLoader : MonoBehaviour
{
    [SerializeField] GameObject loaderObjectsGrp;
    [SerializeField] GameObject ReadyToGoButton;
    string bundlePath;
    public List<string> BundleList;
    string[] FullFileList;
    int totalNumber;
    int numberDone;
    [SerializeField] TMP_Text Uiloaded;
    [SerializeField] TMP_Text UiMax;
    [SerializeField] TMP_Text SillyText;
    [SerializeField] string[] SillyTextLibrary;
    [SerializeField] Slider LoadSlider;

    // Start is called before the first frame update
    void Start()
    {
        loaderObjectsGrp.SetActive(true);
        SillyText.text = SillyTextLibrary[Random.Range(0,SillyTextLibrary.Count()-1)];
        bundlePath = Application.persistentDataPath + "/AssetBundles/";
        //Juuuuuuuuust in case.
        AssetBundle.UnloadAllAssetBundles(true);
        //First get all asset bundles.
        FullFileList = Directory.GetFiles(bundlePath);
        foreach (string file in FullFileList){
            if(!file.Contains(".manifest") & !file.Contains(".txt")){
                BundleList.Add(Path.GetFileName(file));
            }
        }
        totalNumber = BundleList.Count();
        UiMax.text = totalNumber.ToString();
        Uiloaded.text = numberDone.ToString();
        //Then store them to ActiveAssetBundles.
        StartCoroutine(LoadAssetBundles());



     
    }

    void FixedUpdate(){
        Uiloaded.text = numberDone.ToString();
    }

        //The launcher coroutine.
    IEnumerator LoadAssetBundles(){
        foreach( string file in BundleList){
            Debug.Log(file);
            yield return StartCoroutine(LoadAssetBundle(file));
            yield return numberDone++;
            yield return SillyText.text = SillyTextLibrary[Random.Range(0,SillyTextLibrary.Count()-1)];
        }
        yield return StartCoroutine( SetGoButton());
        //yield return StartCoroutine(LoadNextScene());
    }
    IEnumerator LoadAssetBundle(string file){
        var bundleLoadRequest = AssetBundle.LoadFromFileAsync(bundlePath+file);
        while (!bundleLoadRequest.isDone)
        {
            yield return LoadSlider.value = bundleLoadRequest.progress*1.1f;
            yield return null;
        }
        ActiveAssetBundles.ActiveBundles.Add(file, bundleLoadRequest.assetBundle);
        //yield return numberDone = ActiveAssetBundles.BundlesLoaded();
        //ActiveAssetBundles.LoadBundle(file,bundlePath+file);
        yield return bundleLoadRequest;
    }
    IEnumerator SetGoButton(){
        loaderObjectsGrp.SetActive(false);
        ReadyToGoButton.SetActive(true);
        yield return null;
    }

    IEnumerator LoadNextScene(){
        SceneManager.LoadScene("Scenes/MainMenuV2"); 
        yield return null;
    }
    public void LoadNextSceneMethod(){
        SceneManager.LoadScene("Scenes/MainMenuV2"); 
    }


}