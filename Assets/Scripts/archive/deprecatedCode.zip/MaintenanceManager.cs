using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.IO;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
public class MaintenanceManager : InitializationCommonFunctions
{
    public Dictionary<string,string> maintenanceData;
    public bool success;

    [SerializeField] public TMP_Text MaintenanceText;
    public bool connectSuccess = false;
    public bool bypassDownload = false;
    public string messageString;
    public bool maintenaceMode;

    // Start is called before the first frame update

    public IEnumerator CheckMaintenanceData(){
        maintenanceData = new Dictionary<string, string>();
        yield return StartCoroutine(GetMaintenanceData());
        yield return StartCoroutine(DoTheRest());

    }

    IEnumerator DoTheRest(){
        bypassDownload = false;
        if(!connectSuccess){
            if(!File.Exists(Application.persistentDataPath + "/AssetBundles/FatButtersAssetBundleVersions.txt")){
                messageString = "You must connect to a network so I can acquire the corgis!";
                maintenaceMode = true;
                bypassDownload = true;

            } else {
                messageString = "Unable to check for updates. Defaulting\n to local files.\nEnjoy the game!";
                bypassDownload = true;
                maintenaceMode = false;
            }
        } else {
            if(maintenanceData["maintenanceMode"].Contains("yes")){
                maintenaceMode = true;
                messageString = "The game is currently in maintenance mode. We are scheduled to return " + maintenanceData["maintenanceModeCompleteTime"];
            } else {
                maintenaceMode = false;
                bypassDownload = false;
                messageString = "initializing download!";
            }
        }
        yield return bypassDownload;
        yield return maintenaceMode;
        yield return messageString;
    }

    IEnumerator GetMaintenanceData(){
        var cert = new ForceAcceptAll();
        UnityWebRequest MaintenanceFile = new UnityWebRequest(remoteDir + "maintenanceData.txt");
        MaintenanceFile.certificateHandler = cert;
        MaintenanceFile.downloadHandler = new DownloadHandlerBuffer();
        yield return MaintenanceFile.SendWebRequest();
        while (!MaintenanceFile.isDone){} //just wait it out.
        cert?.Dispose();
        if(MaintenanceFile.result != UnityWebRequest.Result.Success){
            connectSuccess = false;
        } else {
            connectSuccess = true;
            string[] textLines = MaintenanceFile.downloadHandler.text.Split("\n");
            foreach (string line in textLines){
                string[] splitLine = line.Split(":");
                maintenanceData.Add(splitLine[0],splitLine[1]);
            }
            yield return maintenanceData;
        }
        yield return connectSuccess;
    }
}
