using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

/*
public class MainMenuRealizer : MonoBehaviour
{
    LevelData levelData;
    [SerializeField] ButtersFileLibrary buttersFileLibrary;
    List<GameObject> levelObjects;
    private AsyncOperationHandle<GameObject> handle;
    // Start is called before the first frame update
    void Start()
    {
        levelObjects = new List<GameObject>();
        buttersFileLibrary = FindAnyObjectByType<ButtersFileLibrary>();
        LoadData();
    }

    // Update is called once per frame

    void LoadData(){
        levelData = buttersFileLibrary.GetMMLevelData();
        StartCoroutine(LoadSkybox());
        foreach(LevelObject obj in levelData.levelObjects){
            try{
            handle = Addressables.LoadAssetAsync<GameObject>(obj.PrefabPath);
            handle.Completed += (operation) => Handle_Completed(obj, operation);
            } catch {}
        }
    }
    private void Handle_Completed(LevelObject obj, AsyncOperationHandle<GameObject> operation){
        if (operation.Status == AsyncOperationStatus.Succeeded){
            //set all stuff before we instantiate...
            operation.Result.tag = obj.tag;
            operation.Result.transform.position = obj.position;
            operation.Result.transform.rotation = obj.rotation;
            operation.Result.transform.localScale = obj.scale;
            //if(obj.ExtraData != ""){
                //operation.Result.GetComponent<InstanceDataParser>().ExtraDataString = obj.ExtraData;
            //}
            GameObject intantiatedObj = Instantiate(operation.Result,obj.position,obj.rotation);
            intantiatedObj.transform.localScale = obj.scale;
            levelObjects.Add(intantiatedObj);
        } else {
            levelObjects.Add(null); //If it doesn't work, it just loads as a blank object and don't spawn it.
        }
    }

    IEnumerator LoadSkybox(){
        AsyncOperationHandle<Material> skybox = Addressables.LoadAssetAsync<Material>(levelData.Skybox);
        yield return skybox;
        skybox.Completed += (operation) => Skybox_Completed(operation);
        yield return null;
    }
        private void Skybox_Completed(AsyncOperationHandle<Material> operation){
        if (operation.Status == AsyncOperationStatus.Succeeded){
            RenderSettings.skybox = operation.Result;
        }

    }

}*/