using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.IO;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using System;
public class AssetPackDownloader : InitializationCommonFunctions
{
    bool newVersionAvailable = false;
    [SerializeField] GameObject VersionUpdateButton;
    [SerializeField] TMP_Text[] TextLines;
    Dictionary<string,string> localFiles;
    Dictionary<string,string> remoteFiles;
    Dictionary<string,int> localVersions;
    Dictionary<string,int> remoteVersions;
    Dictionary<string, bool> whatToUpdate;
    Dictionary<string,string> whatToDelete;
    Vector3Int localVersionCode;
    Vector3Int remoteVersionCode;
    string initialFileText;
    string platform;
    int DataLength = 5;
    string fullRemoteVersionText;
    [SerializeField] GameObject bgObj;
    [SerializeField] ParticleSystem corgiRain;
    [SerializeField] bool bypassAssetDownload;

    // Start is called before the first frame update
    void Start()
    {
        if(bypassAssetDownload){
            GoToNextStep();
        } else {
        StartCoroutine(DownloaderTopLayer());
        }
    }


    IEnumerator DownloaderTopLayer(){
        yield return StartCoroutine(EnsureCorrectPlatform());
        yield return StartCoroutine(InitialSetup());
        yield return StartCoroutine(EnsureFileStructureAndInitialVersionDoc());
        yield return StartCoroutine(FinalizeInitialSetup());
        yield return StartCoroutine(LocalDictionarySetup());
        yield return StartCoroutine(DownloadVersionFile());
        if(DoWeNeedToUpgradeNewVersion()){
            bgObj.SetActive(false);
            TextLines[0].text = "Oop! Hold on!";
            TextLines[1].text = "There seems to be a new version available.";
            TextLines[2].text = "Go ahead and download that and come back here when you're done.";
            TextLines[3].text = "";
            VersionUpdateButton.SetActive(true);
            yield return null;
            yield break;
        }
        yield return StartCoroutine(FigureOutWhatToUpdate());
        yield return StartCoroutine(FigureOutWhatToDelete());
        

        //delete what's not necessary anymore.
        foreach (KeyValuePair<string,string> pair in whatToDelete){
            File.Delete(pair.Value);
        }

        TextLines[1].text = "Acquiring Asset Packages";
        foreach(KeyValuePair<string,bool> file in whatToUpdate){
            if(file.Value == true){
                if (corgiRain.isStopped){
                    bgObj.SetActive(false);
                    corgiRain.gameObject.SetActive(true) ;
                    corgiRain.Play();
                }
                yield return null;
                yield return StartCoroutine(DownloadAssetBundle(localFiles[file.Key],remoteFiles[file.Key],"Downloading " + file.Key));
            }
        }
        //yield return StartCoroutine(DeleteObsoleteData());
        yield return StartCoroutine(UpdateLocalVersionDoc());
        yield return StartCoroutine(LoadNextScene());
        yield return null;
    }

    IEnumerator UpdateLocalVersionDoc(){
        StreamWriter writer = new StreamWriter(localFiles["versionDoc"]);
        writer.Write(fullRemoteVersionText);
        writer.Close();
        yield return null;
    }



    IEnumerator LoadNextScene(){
                SceneManager.LoadScene("Scenes/StatsAndLoaderScenes/5-SocialNetworkInitialization");
        yield return null;
    }
    IEnumerator EnsureCorrectPlatform()
    {
        switch (Application.platform){
            case RuntimePlatform.WindowsPlayer:
                platform = "Windows/";
                break;
            case RuntimePlatform.IPhonePlayer:
                platform = "iOS/";
                break;
            case RuntimePlatform.Android:
                platform = "Android/";
                break;
            default:
                platform = "Windows/";
                break;
        }
        yield return platform;
    }
    IEnumerator InitialSetup(){
        initialFileText = "versioncode:" + Application.version;
        localFiles = new Dictionary<string,string>();
        whatToUpdate = new Dictionary<string,bool>();
        whatToDelete = new Dictionary<string,string>();
        remoteFiles = new Dictionary<string,string>();
        localVersions = new Dictionary<string,int>();
        remoteVersions = new Dictionary<string,int>();
        localFiles.Add("versionDoc",Application.persistentDataPath + AssetBundleDir + "FatButtersAssetBundleVersions.txt");
        remoteFiles.Add("versionDoc",remoteDir+AssetBundleDir+"FatButtersAssetBundleVersions.txt");
        yield return localFiles;
        yield return whatToUpdate;
        yield return whatToDelete;
        yield return remoteFiles;
        yield return localVersions;
        yield return remoteVersions;
    }
    IEnumerator EnsureFileStructureAndInitialVersionDoc(){
        if (!Directory.Exists(Application.persistentDataPath + AssetBundleDir)){
            Directory.CreateDirectory(Application.persistentDataPath + AssetBundleDir);
        }
        if (!File.Exists(localFiles["versionDoc"])){
            StreamWriter writer = new StreamWriter(localFiles["versionDoc"]);
            writer.Write(initialFileText);
            writer.Close();
        }
        yield return null;
    }
    IEnumerator FinalizeInitialSetup(){
        localVersions = ParseLocalVersionData(DataLength, File.ReadAllLines(localFiles["versionDoc"]));
        yield return localVersions;
    }
    IEnumerator GetVersionData(){

        yield return null;
    }
    IEnumerator LocalDictionarySetup(){
        StreamReader localVersionDoc = new StreamReader(localFiles["versionDoc"]);
        string[] localLines = localVersionDoc.ReadToEnd().Split("\n");
        foreach (string line in localLines){
            string[] subline = line.Split(":");
            if(subline[0] != "versioncode"){
                //If it's not the version doc, don't forget to add the manifest as well.
                localFiles.Add(subline[0] + "Manifest",Application.persistentDataPath + AssetBundleDir + subline[0] + ".manifest");
                localFiles.Add(subline[0],Application.persistentDataPath + AssetBundleDir + subline[0]);
            } else {
                
                string[] VCString = Application.version.Split(".");
                localVersionCode = new Vector3Int(int.Parse(VCString[0]),int.Parse(VCString[1]),int.Parse(VCString[2]));
            }
        }
        yield return localFiles;
        yield return localVersionCode;
        localVersionDoc.Close();
        yield return null;

    }
    IEnumerator DownloadVersionFile(){
        fullRemoteVersionText = "";
        var cert = new ForceAcceptAll();
        //UnityWebRequest versionFile = new UnityWebRequest(remoteDir + "FatButtersAssetBundleVersions.txt"); //Production
        UnityWebRequest versionFile = new UnityWebRequest(remoteDir + "AssetBundleVersionsV2.txt"); //For testing
        versionFile.certificateHandler = cert;
        versionFile.downloadHandler = new DownloadHandlerBuffer();
        yield return versionFile.SendWebRequest();
        cert?.Dispose();
        while (!versionFile.isDone){
            TextLines[1].text = "Checking version data...";
            TextLines[3].text = versionFile.downloadProgress.ToString() + "%";
        }
        TextLines[1].text = "";
        TextLines[3].text = "";
        fullRemoteVersionText = versionFile.downloadHandler.text;
        yield return fullRemoteVersionText;
        string[] dataArray = fullRemoteVersionText.Split("\n");
        remoteVersions = ParseRemoteVersionData(DataLength,dataArray);
        yield return remoteVersions;
        yield return remoteVersionCode;
        string[] currentVersionStringArray = Application.version.Split(".");
        Vector3Int currentVersion = new Vector3Int(int.Parse(currentVersionStringArray[0]),int.Parse(currentVersionStringArray[1]),int.Parse(currentVersionStringArray[2]));
        foreach (KeyValuePair<string,int> filever in remoteVersions){
            if(filever.Key != "versioncode"){
                remoteFiles.Add(filever.Key,remoteDir+platform+filever.Key);
                remoteFiles.Add(filever.Key+"Manifest",remoteDir+platform+filever.Key+".manifest");
            }
        }
        yield return remoteFiles;
    }

    IEnumerator FigureOutWhatToUpdate(){
        
        foreach(KeyValuePair<string,int> fileversion in remoteVersions){
            try{
                if(fileversion.Value != localVersions[fileversion.Key] | !localVersions.ContainsKey(fileversion.Key)){
                    whatToUpdate.Add(fileversion.Key,true);
                    whatToUpdate.Add(fileversion.Key+"Manifest",true);
                } else {
                    whatToUpdate.Add(fileversion.Key,false);
                    whatToUpdate.Add(fileversion.Key+"Manifest",false);
                }
            } catch (KeyNotFoundException e){
                localFiles.Add(fileversion.Key, Application.persistentDataPath + AssetBundleDir + fileversion.Key);
                localFiles.Add(fileversion.Key+"Manifest", Application.persistentDataPath + AssetBundleDir + fileversion.Key + ".manifest");
                whatToUpdate.Add(fileversion.Key,true);
                whatToUpdate.Add(fileversion.Key+"Manifest",true);

            }
        }
        yield return whatToUpdate;
    }

    IEnumerator FigureOutWhatToDelete(){
        foreach(KeyValuePair<string,int> localFile in localVersions){
            if(!remoteVersions.ContainsKey(localFile.Key)){
                whatToDelete.Add(localFile.Key,localFiles[localFile.Key]);
                whatToDelete.Add(localFile.Key+"Manifest",localFiles[localFile.Key+"Manifest"]);
            }
        }
        yield return whatToDelete;
    }
    IEnumerator DeleteObsoleteData(){
        foreach(KeyValuePair<string,string> deletableFile in whatToDelete){
            Debug.Log(Application.persistentDataPath + AssetBundleDir + deletableFile.Key);
            File.Delete(Application.persistentDataPath + AssetBundleDir + deletableFile.Key);
            
        }
        yield return null;
    }
    IEnumerator DownloadAssetBundle(string localLocation, string remoteLocation, string niceText){
        TextLines[2].text = niceText;
        var cert = new ForceAcceptAll();
        UnityWebRequest request = new UnityWebRequest(remoteLocation,UnityWebRequest.kHttpVerbGET);
        request.certificateHandler = cert;
        request.downloadHandler = new DownloadHandlerFile(localLocation);
        request.SendWebRequest();
        cert?.Dispose();
        while (!request.isDone){
            TextLines[3].text = (request.downloadProgress * 100.0f).ToString() + "%";
            yield return null;
        }
        yield return null;
    }



    private Dictionary<string,int> ParseRemoteVersionData(int size, string[] inputData)
    {
        Dictionary<string,int> output = new Dictionary<string, int>();
        foreach (string line in inputData)
        {
            if(line == ""){
                continue;
            }
            string[] subline = line.Split(":");
            if(subline[0] != "versioncode"){
                output.Add(subline[0], int.Parse(subline[1]));
            } else {
                string[] VCString = subline[1].Split(".");
                remoteVersionCode = new Vector3Int(int.Parse(VCString[0]),int.Parse(VCString[1]),int.Parse(VCString[2])) ;
            }
        }
        return output;
    }

    private Dictionary<string,int> ParseLocalVersionData(int size, string[] inputData){
        Dictionary<string,int> output = new Dictionary<string, int>();
        foreach (string line in inputData)
        {
            string[] subline = line.Split(":");
            if(subline[0] != "versioncode"){
                output.Add(subline[0], int.Parse(subline[1]));
            } else {
                string[] VCString = subline[1].Split(".");
                localVersionCode = new Vector3Int(int.Parse(VCString[0]),int.Parse(VCString[1]),int.Parse(VCString[2])) ;
            }
        }
        return output;
    }
    public void UpdateURL(){
        Application.OpenURL("https://play.google.com/store/apps/details?id=com.SimeckEntertainment.FatButtersJetpackRide&pli=1");
    }
    void GoToNextStep(){
        SceneManager.LoadScene("Scenes/StatsAndLoaderScenes/5-SocialNetworkInitialization");
    }

    bool DoWeNeedToUpgradeNewVersion(){
        if(localVersionCode.x<remoteVersionCode.x){
            return true;
        }
        if(localVersionCode.x>remoteVersionCode.x){
            return false;
        }
        if(localVersionCode.y<remoteVersionCode.y){
            return true;
        }
        if(localVersionCode.y>remoteVersionCode.y){
            return false;
        }
        if(localVersionCode.z<remoteVersionCode.z){
            return true;
        }
        return false;
    }
}
