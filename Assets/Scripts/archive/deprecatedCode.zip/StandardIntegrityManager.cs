using GooglePlayGames;
using GooglePlayGames.BasicApi;
using Google.Play.Integrity;
using UnityEngine;
public class StandardIntegrityManager : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    
    }

}
