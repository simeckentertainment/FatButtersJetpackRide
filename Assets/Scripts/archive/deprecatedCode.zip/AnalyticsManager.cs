using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Services.Core;
using Unity.Services.Analytics;

public class AnalyticsManager : InitializationCommonFunctions
{//
    public bool success;
    [SerializeField] GameObject AnalyticsConsentCanvas;
    [SerializeField] GameObject AgeGateCanvas;
    // Start is called before the first frame update
    async void Start()
    {
        await UnityServices.InitializeAsync();
        CheckForConsent();

    }

    public IEnumerator CheckForConsent()
    {
        if (saveManager.userInfo.dataCollectionChosen){
            if (saveManager.userInfo.dataCollectionConsent){
                ConsentGiven();
            } else {
                ConsentNotGiven();
            }
            //initData.analyticsConsentAnswered = true;
        } else {
            AnalyticsConsentCanvas.SetActive(true);
            AskForConsent();
            //initData.analyticsConsentAnswered = false;
        }
        //while(!initData.analyticsConsentAnswered){
            //yield return null;
        //}
        //base.analyticsSuccess = true;
        yield return success = true;
        //yield return initData.analyticsConsentAnswered;
        AnalyticsConsentCanvas.SetActive(false);
        yield return null;
        
    }

    
    public void AskForConsent(){
        gameObject.SetActive(true);
    }
    public void ConsentGiven()
	{
		AnalyticsService.Instance.StartDataCollection();
        saveManager.userInfo.dataCollectionChosen = true;
        saveManager.userInfo.dataCollectionConsent = true;
        ActivateNextScreeen();
	}

    public void ConsentNotGiven(){
        saveManager.userInfo.dataCollectionChosen = true;
        saveManager.userInfo.dataCollectionConsent = false;
        ActivateNextScreeen();

    }
    void  ActivateNextScreeen(){
        saveManager.Save();
        //initData.analyticsConsentAnswered = true;
    }
    public void ThirteenPlus(){
        saveManager.userInfo.isOldEnoughForAds = true;
    }
    public void UnderThirteen(){
        saveManager.userInfo.isOldEnoughForAds = false;
    }
}
