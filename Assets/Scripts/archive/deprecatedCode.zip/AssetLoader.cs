using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.IO;
using UnityEngine.Networking;
public class AssetLoader : InitializationCommonFunctions
{ 
    [SerializeField] public TMP_Text LabelText;
    [SerializeField] public TMP_Text CurrentItemText;
    [SerializeField] public TMP_Text ProgressText;

    bool haveLevel1;
    bool haveLevel2;
    bool haveLevel3;
    bool havePowerups;

    string platform;
    string initialFileText;
    int DataLength = 5;
    Dictionary<string,string> localFiles;
    Dictionary<string,string> remoteFiles;
    Dictionary<string,int> localVersions;
    Dictionary<string,int> remoteVersions;
    Dictionary<string, bool> whatToUpdate;
    Dictionary<string,string> whatToDelete;
    Vector3Int localVersionCode;
    Vector3Int remoteVersionCode;
    [SerializeField] public bool NeedToUpdateFromAppStore;
    bool CreatedNewVersionFile;
    [SerializeField] public GameObject DownloadButton;
    

    // Start is called before the first frame update

    public IEnumerator DownloadCoroutineLauncher(){
        yield return StartCoroutine(InitialSetup());
        //Ensures that we have the correct local file structure.
        yield return StartCoroutine(EnsureFileStructureAndInitialVersionDoc());
        //Just tells us which files to get from remote.
        yield return StartCoroutine(EnsureCorrectPlatform());
        yield return StartCoroutine(FinalizeInitialSetup());
        //At this point we should at the very least have an initial version file.
        //Set up the local version dictionary.
        yield return StartCoroutine(LocalDictionarySetup());
        //Download the version file and set up the remote version dictionary.
        yield return StartCoroutine(DownloadVersionFile());
        //Figure out what new files need to be downloaded or overwritten.

        yield return StartCoroutine(FigureOutWhatToUpdate());
        //Determine files needing deletion.
        yield return StartCoroutine(FigureOutWhatToDelete());
        //Download what needs downloading.
        foreach(KeyValuePair<string,bool> file in whatToUpdate){
            if(file.Value == true){
                yield return StartCoroutine(DownloadAssetBundle(localFiles[file.Key],remoteFiles[file.Key],"Downloading " + file.Key));
            }
        }
        /*Delete what needs deleting. Future Feature.
        foreach(KeyValuePair<string,string> file in whatToDelete){

        }*/
        //Finally, update the local version doc
        yield return StartCoroutine(UpdateVersionDoc());
        yield return null;
    }

    IEnumerator InitialSetup(){
        initialFileText = "versioncode:" + Application.version + "\nlevel1:0\nlevel2:0\nlevel3:0\nmainMenu:0\ntutorial:0";
        NeedToUpdateFromAppStore = false;
        localFiles = new Dictionary<string,string>();
        whatToUpdate = new Dictionary<string,bool>();
        whatToDelete = new Dictionary<string,string>();
        remoteFiles = new Dictionary<string,string>();
        localFiles.Add("versionDoc",Application.persistentDataPath + AssetBundleDir + "FatButtersAssetBundleVersions.txt");
        remoteFiles.Add("versionDoc",remoteDir+AssetBundleDir+"FatButtersAssetBundleVersions.txt");
        yield return initialFileText;
        yield return NeedToUpdateFromAppStore;
        yield return localFiles;
        yield return whatToUpdate;
        yield return whatToDelete;
        yield return remoteFiles;
    }
    IEnumerator EnsureCorrectPlatform()
    {
        switch (Application.platform){
            case RuntimePlatform.WindowsPlayer:
                platform = "Windows/";
                break;
            case RuntimePlatform.IPhonePlayer:
                platform = "iOS/";
                break;
            case RuntimePlatform.Android:
                platform = "Android/";
                break;
            default:
                platform = "Windows/";
                break;
        }
        yield return platform;
    }
    IEnumerator EnsureFileStructureAndInitialVersionDoc(){
        CreatedNewVersionFile = false;
        if (!Directory.Exists(Application.persistentDataPath + AssetBundleDir)){
            CreatedNewVersionFile = true;
            Directory.CreateDirectory(Application.persistentDataPath + AssetBundleDir);
        } else {
            CreatedNewVersionFile = false;
        }
        if (!File.Exists(localFiles["versionDoc"])){
            StreamWriter writer = new StreamWriter(localFiles["versionDoc"]);
            writer.Write(initialFileText);
            writer.Close();
        }
        yield return null;
    }
    IEnumerator FinalizeInitialSetup(){
        localVersions = ParseLocalVersionData(DataLength, File.ReadAllLines(localFiles["versionDoc"]));
        yield return localVersions;
    }
    IEnumerator LocalDictionarySetup(){
        StreamReader localVersionDoc = new StreamReader(localFiles["versionDoc"]);
        string[] localLines = localVersionDoc.ReadToEnd().Split("\n");
        foreach (string line in localLines){
            string[] subline = line.Split(":");
            if(subline[0] != "versioncode"){
                //If it's not the version doc, don't forget to add the manifest as well.
                localFiles.Add(subline[0] + "Manifest",Application.persistentDataPath + AssetBundleDir + subline[0] + ".manifest");
                localFiles.Add(subline[0],Application.persistentDataPath + AssetBundleDir + subline[0]);
            } else {
                string[] VCString = subline[1].Split(".");
                localVersionCode = new Vector3Int(int.Parse(VCString[0]),int.Parse(VCString[1]),int.Parse(VCString[2])) ;
            }
        }
        
        localVersionDoc.Close();
        yield return localFiles;
    }
    IEnumerator DownloadVersionFile(){
        string versionData = "";
        var cert = new ForceAcceptAll();
        UnityWebRequest versionFile = new UnityWebRequest(remoteDir + "FatButtersAssetBundleVersions.txt");
        versionFile.certificateHandler = cert;
        versionFile.downloadHandler = new DownloadHandlerBuffer();
        yield return versionFile.SendWebRequest();
        cert?.Dispose();
        while (!versionFile.isDone){
            yield return LabelText.text = "Checking version data...";
            yield return CurrentItemText.text = versionFile.downloadProgress.ToString() + "%";
        }

        versionData = versionFile.downloadHandler.text;
        string[] dataArray = versionData.Split("\n");
        remoteVersions = ParseRemoteVersionData(DataLength,dataArray);
        yield return remoteVersions;
        yield return remoteVersionCode;

        string[] currentVersionStringArray = Application.version.Split(".");
        Vector3Int currentVersion = new Vector3Int(int.Parse(currentVersionStringArray[0]),int.Parse(currentVersionStringArray[1]),int.Parse(currentVersionStringArray[2]));
        if(remoteVersionCode != currentVersion){
            yield return NeedToUpdateFromAppStore = true;
            yield break;
        }
        foreach (KeyValuePair<string,int> filever in remoteVersions){
            if(filever.Key != "versioncode"){
                remoteFiles.Add(filever.Key,remoteDir+platform+filever.Key);
                remoteFiles.Add(filever.Key+"Manifest",remoteDir+platform+filever.Key+".manifest");
            }
        }
        yield return remoteFiles;
    }
    IEnumerator FigureOutWhatToUpdate(){
        
        foreach(KeyValuePair<string,int> fileversion in remoteVersions){
            if(fileversion.Value != localVersions[fileversion.Key] | !localVersions.ContainsKey(fileversion.Key)){
                whatToUpdate.Add(fileversion.Key,true);
                whatToUpdate.Add(fileversion.Key+"Manifest",true);
            } else {
                whatToUpdate.Add(fileversion.Key,false);
                whatToUpdate.Add(fileversion.Key+"Manifest",false);
            }
        }
        yield return whatToUpdate;
    }
    IEnumerator FigureOutWhatToDelete(){
        foreach(KeyValuePair<string,int> localFile in localVersions){
            if(!remoteVersions.ContainsKey(localFile.Key)){
                whatToDelete.Add(localFile.Key,localFiles[localFile.Key]);
                whatToDelete.Add(localFile.Key+"Manifest",localFiles[localFile.Key+"Manifest"]);
            }
        }
        yield return whatToDelete;
    }
    IEnumerator DownloadAssetBundle(string localLocation, string remoteLocation, string niceText){
        yield return CurrentItemText.text = niceText;
        var cert = new ForceAcceptAll();
        UnityWebRequest request = new UnityWebRequest(remoteLocation,UnityWebRequest.kHttpVerbGET);
        request.certificateHandler = cert;
        request.downloadHandler = new DownloadHandlerFile(localLocation);
        request.SendWebRequest();
        cert?.Dispose();
        Debug.Log((request.downloadProgress * 100.0f).ToString() + "%");
        while (!request.isDone){
            ProgressText.text = (request.downloadProgress * 100.0f).ToString() + "%";
            yield return null;
        }
        yield return null;
    }
    IEnumerator UpdateVersionDoc(){
        string versionData = "";
        var cert = new ForceAcceptAll();
        UnityWebRequest versionFile = new UnityWebRequest("https://fatbutters.simeck.com/AssetBundles/FatButtersAssetBundleVersions.txt");
        versionFile.certificateHandler = cert;
        versionFile.downloadHandler = new DownloadHandlerBuffer();
        yield return versionFile.SendWebRequest();
        cert?.Dispose();
        while (!versionFile.isDone){
            CurrentItemText.text = versionFile.downloadProgress.ToString() + "%";
            yield return CurrentItemText.text;
        }
        if (versionFile.result != UnityWebRequest.Result.Success){
            Debug.Log(versionFile.error);
            yield return null;
        } else {
            versionData = versionFile.downloadHandler.text;
        }
        File.Delete(Application.persistentDataPath + AssetBundleDir + "FatButtersAssetBundleVersions.txt");
        StreamWriter writer = new StreamWriter(localFiles["versionDoc"]);
        writer.Write(versionData);
        writer.Close();
        updateComplete = true;
        yield return updateComplete;
        yield return null;
    }



    private Dictionary<string,int> ParseRemoteVersionData(int size, string[] inputData)
    {
        Dictionary<string,int> output = new Dictionary<string, int>();
        foreach (string line in inputData)
        {
            if(line == ""){
                continue;
            }
            string[] subline = line.Split(":");
            if(subline[0] != "versioncode"){
                output.Add(subline[0], int.Parse(subline[1]));
            } else {
                string[] VCString = subline[1].Split(".");
                remoteVersionCode = new Vector3Int(int.Parse(VCString[0]),int.Parse(VCString[1]),int.Parse(VCString[2])) ;
            }
        }
        return output;
    }
    private Dictionary<string,int> ParseLocalVersionData(int size, string[] inputData)
    {
        Dictionary<string,int> output = new Dictionary<string, int>();
        foreach (string line in inputData)
        {
            string[] subline = line.Split(":");
            if(subline[0] != "versioncode"){
                output.Add(subline[0], int.Parse(subline[1]));
            } else {
                string[] VCString = subline[1].Split(".");
                localVersionCode = new Vector3Int(int.Parse(VCString[0]),int.Parse(VCString[1]),int.Parse(VCString[2])) ;
            }
        }
        return output;
    }




    public void UpdateURL(){
        Application.OpenURL("https://play.google.com/store/apps/details?id=com.SimeckEntertainment.FatButtersJetpackRide&pli=1");
    }
}



